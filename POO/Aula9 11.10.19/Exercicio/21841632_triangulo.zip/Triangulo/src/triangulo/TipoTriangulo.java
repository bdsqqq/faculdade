
package triangulo;



public class TipoTriangulo extends Triangulo {
    
    private String tipoTriangulo;

   
    public TipoTriangulo(float ladoA, float ladoB, float ladoC) {
		super(ladoA, ladoB, ladoC);
	}

    public String validaTipo(){
        if (getLadoA() == getLadoB() && getLadoB() == getLadoC()){
            return tipoTriangulo = "Triângulo Equilátero";
                 
        } else if (getLadoA() == getLadoB() || getLadoA() == getLadoC() || getLadoB() == getLadoC()){
            return tipoTriangulo = "Triângulo Isóscele";
                 
        } else {
            return tipoTriangulo = "Triângulo Escaleno";
        }
        
    }

    
    
}
