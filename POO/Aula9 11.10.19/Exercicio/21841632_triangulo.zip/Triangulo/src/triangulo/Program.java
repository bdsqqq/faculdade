
package triangulo;

import static java.lang.Float.parseFloat;
import javax.swing.JOptionPane;

public class Program  {
    
    public static void main(String[] args) {
        String anguloTipo = null;
       
        
       float ladoA = parseFloat(JOptionPane.showInputDialog(null, "Digite o valor do lado A")) ;
       float ladoB = parseFloat(JOptionPane.showInputDialog(null, "Digite o valor do lado B")) ;
       float ladoC = parseFloat(JOptionPane.showInputDialog(null, "Digite o valor do lado C")) ;
        
       float anguloX = parseFloat(JOptionPane.showInputDialog(null, "Digite o valor do Angulo X")) ;
       float anguloY = parseFloat(JOptionPane.showInputDialog(null, "Digite o valor do Angulo Y")) ;
       float anguloZ = parseFloat(JOptionPane.showInputDialog(null, "Digite o valor do Angulo Z")) ;
      
       TipoTriangulo objTriangulo = new TipoTriangulo(ladoA, ladoB, ladoC);
       AnguloTriangulo objAngulo = new AnguloTriangulo(anguloX, anguloY, anguloZ, anguloTipo);
       JOptionPane.showMessageDialog(null, objTriangulo.validaTipo() + " & " + objAngulo.validaAngulo());
       
       
    }
    
}
