
package triangulo;


public class AnguloTriangulo extends Triangulo {
    
     private float anguloX;
    private float anguloY;
    private float anguloZ;
    private float anguloTipo;
    
    
    public AnguloTriangulo(float anguloX, float anguloY, float anguloZ, String anguloTipo) {
        this.setAnguloX (anguloX);
        this.setAnguloY(anguloY);
        this.setAnguloZ (anguloZ);
    }
    
     public float getAnguloX() {
        return anguloX;
    }

    public void setAnguloX(float anguloX) {
        this.anguloX = anguloX;
    }

    public float getAnguloY() {
        return anguloY;
    }

    public void setAnguloY(float anguloY) {
        this.anguloY = anguloY;
    }

    public float getAnguloZ() {
        return anguloZ;
    }

    public void setAnguloZ(float anguloZ) {
        this.anguloZ = anguloZ;
    }

    public float getAnguloTipo() {
        return anguloTipo;
    }

    public void setAnguloTipo(float anguloTipo) {
        this.anguloTipo = anguloTipo;
    }
    
    private String anguloTriangulo;
    


    public String validaAngulo(){
        if (getAnguloX() == 90f || getAnguloY() == 90f || getAnguloZ() == 90f){
            return anguloTriangulo = "Triângulo Retângulo";
                 
        } else if (getAnguloX() > 90f || getAnguloY() > 90f || getAnguloZ() > 90f){
            return anguloTriangulo = "Triângulo Obtusângulo";
                 
        } else {
            return anguloTriangulo = "Triângulo Acutângulo";
        }
        
    }
    
}
