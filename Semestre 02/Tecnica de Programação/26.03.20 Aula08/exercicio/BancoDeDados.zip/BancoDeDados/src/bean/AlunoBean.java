package bean;

public class AlunoBean {
    public float calculaMedia(float nota1, float nota2){
        return nota1+nota2;
    }
}
