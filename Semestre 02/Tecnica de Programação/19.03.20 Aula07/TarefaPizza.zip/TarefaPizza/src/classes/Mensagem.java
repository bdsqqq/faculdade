
package classes;


public class Mensagem {
    
    private String cor;
    private int tamanho;
    private String msg;
    private String tooltip;

    public String getCor() {
        return cor;
    }

    public int getTamanho() {
        return tamanho;
    }

    public String getMsg() {
        return msg;
    }

    public String getTooltip() {
        return tooltip;
    }

    public void setCor(String cor) {
        this.cor = cor;
    }

    public void setTamanho(int tamanho) {
        this.tamanho = tamanho;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    public void setTooltip(String tooltip) {
        this.tooltip = tooltip;
    }
    
    
    /*private Mensagem getMensagem() {
        Mensagem mensagem = new Mensagem();
        
        mensagem.setCor(lstCor.getSelectedValue().toString());
        mensagem.setTamanho(Integer.parseInt(lstTamanho.getSelectedValue().toString()));
        mensagem.setMsg(txtTexto.getText());
        mensagem.setTooltip(txtToolTip.getText());
        
        return mensagem;
    }
    */
    
}
