
package bean;

import classes.Mensagem;
import java.awt.Color;
import java.awt.Font;
import javax.swing.JLabel;


public class MensagemBean {
    
    public void modificarLabel(Mensagem mensagem, JLabel label) {
        
        label.setText(mensagem.getMsg());
        label.setFont(new Font("Arial",Font.PLAIN, mensagem.getTamanho()));
        label.setToolTipText(mensagem.getTooltip());
        
        switch(mensagem.getCor()){
            case "Branco":
                label.setForeground(Color.WHITE);
                break;
            case "Preto":
                label.setForeground(Color.BLACK);
                break;
            case "Azul":
                label.setForeground(Color.BLUE);
                break;
            case "Amarelo":
                label.setForeground(Color.YELLOW);
                break;    
            case "Vermelho":
                label.setForeground(Color.RED);
                break;
            case "Rosa":
                label.setForeground(Color.PINK);
                break;    
                
    }
        
        
    }
}
