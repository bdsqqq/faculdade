
package avaliacao;

public class Principal {
    Avaliacao objAvaliacao = new Avaliacao();
    
}
