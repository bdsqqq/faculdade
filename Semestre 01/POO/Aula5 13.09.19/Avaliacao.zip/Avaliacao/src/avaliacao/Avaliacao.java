
package avaliacao;

public class Avaliacao {
    private String nome;
    private String tipoAvaliacao;
    private float notaMaxima;
    private float percentualFinalNota;
    

    public Avaliacao(String nome, String tipoAvaliacao, float notaMaxima) {
        this.nome = nome;
        this.tipoAvaliacao = tipoAvaliacao;
        this.notaMaxima = notaMaxima;
    }

    public Avaliacao() {
      
    }

    public float calcularPer(){
        percentualFinalNota =  ((notaMaxima / 10.0f)*100.0f);
        return percentualFinalNota;
        
    }

    @Override
    public String toString() {
        return "Avaliacao{" + "nome=" + nome + ", tipoAvaliacao=" + tipoAvaliacao + ", notaMaxima=" + notaMaxima + ", percentualFinalNota=" + percentualFinalNota + '}';
    }
    

    public static void main(String[] args) {
        Avaliacao objAvaliacao = new Avaliacao();
        objAvaliacao.toString();
        
    }
    
    
}
