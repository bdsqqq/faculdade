
package teste;

import pessoa.*;

public class teste {
    
        public static void main(String[] args) {
        Pessoa objPessoa = new Pessoa();
        
        System.out.println("O nome é " + objPessoa.getNome());
        objPessoa.setNome("Atos");
        System.out.println("O nome é " + objPessoa.getNome());
        
    }
}
