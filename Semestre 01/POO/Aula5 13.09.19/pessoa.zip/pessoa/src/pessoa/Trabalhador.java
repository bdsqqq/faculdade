package pessoa;

public class Trabalhador {
    private float salario;
    private String registro;
    
    
    public Trabalhador(){
        salario = 12.58f;
        registro = "123-DA";
            
    }
    
 
    public static void main(String[] args) {
        Pessoa objPessoa = new Pessoa();
        
        System.out.println("O nome é " + objPessoa.getNome());
        objPessoa.setNome("Atos");
        System.out.println("O nome é " + objPessoa.getNome());
        
    }
    
}
