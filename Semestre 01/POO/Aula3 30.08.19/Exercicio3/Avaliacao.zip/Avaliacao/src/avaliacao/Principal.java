package avaliacao;

public class Principal {
    Avaliacao objAvaliacao2 = new Avaliacao();
}
