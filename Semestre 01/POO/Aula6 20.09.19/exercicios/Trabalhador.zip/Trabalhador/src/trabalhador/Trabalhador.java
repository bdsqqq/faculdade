/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package trabalhador;
import javax.swing.JOptionPane;

public class Trabalhador {

    private String cpf;
    private String nome;
    private int idade;
    private String sexo;
    private String endereço;
    private float salario;

    public String getCpf() {
        return cpf;
    }

    public void setCpf(String cpf) {
        this.cpf = cpf;
    }

    public String getNome() {
        return nome;
    }

    public void setNome(String nome) {
        this.nome = nome;
    }

    public int getIdade() {
        return idade;
    }

    public void setIdade(int idade) {
        this.idade = idade;
    }

    public String getSexo() {
        return sexo;
    }

    public void setSexo(String sexo) {
        this.sexo = sexo;
    }

    public String getEndereço() {
        return endereço;
    }

    public void setEndereço(String endereço) {
        this.endereço = endereço;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public Trabalhador(String cpf, String nome, int idade, String sexo, String endereço, float salario) {
        this.cpf = cpf;
        this.nome = nome;
        this.idade = idade;
        this.sexo = sexo;
        this.endereço = endereço;
        this.salario = salario;
    }
    
    public Trabalhador(){
        this.cpf = JOptionPane.showInputDialog(null, "Digite seu CPF", "cpf", JOptionPane.INFORMATION_MESSAGE);
        this.nome = JOptionPane.showInputDialog(null, "Digite seu nome", "nome", JOptionPane.INFORMATION_MESSAGE);
        this.idade = Integer.parseInt(JOptionPane.showInputDialog(null, "Digite sua idade", "idade", JOptionPane.INFORMATION_MESSAGE));
        this.sexo = JOptionPane.showInputDialog(null, "Digite seu sexo", "sexo", JOptionPane.INFORMATION_MESSAGE);
        this.endereço = JOptionPane.showInputDialog(null, "Digite seu endereço", "endereço", JOptionPane.INFORMATION_MESSAGE);
        this.salario = Float.parseFloat(JOptionPane.showInputDialog(null, "Digite seu salario", "salario", JOptionPane.INFORMATION_MESSAGE));
    }
    
    public static void main(String[] args) {
        JOptionPane.showMessageDialog(null, "Trabalhador 1", "Trabalhador 1", JOptionPane.INFORMATION_MESSAGE);
        Trabalhador objTrabalhador1 = new Trabalhador();
        JOptionPane.showMessageDialog(null, "Trabalhador 2", "Trabalhador 2", JOptionPane.INFORMATION_MESSAGE);
        Trabalhador objTrabalhador2 = new Trabalhador();
        JOptionPane.showMessageDialog(null, "Trabalhador 3", "Trabalhador 3", JOptionPane.INFORMATION_MESSAGE);
        Trabalhador objTrabalhador3 = new Trabalhador();
        JOptionPane.showMessageDialog(null, "Trabalhador 4", "Trabalhador 4", JOptionPane.INFORMATION_MESSAGE);
        Trabalhador objTrabalhador4 = new Trabalhador();
        
        float soma = 0.0f;
        soma = objTrabalhador1.getSalario()+objTrabalhador2.getSalario()+objTrabalhador3.getSalario()+objTrabalhador4.getSalario();
        
        float media = soma/4;
        
        System.out.println("A média do salario é:"+media);
        
        
        float somaf = 0.0f;
        int nf = 0;    
        if(objTrabalhador1.getSexo().equalsIgnoreCase("Feminino")){
            somaf = somaf + objTrabalhador1.getSalario();
           nf += 1;
        }
        
        if(objTrabalhador2.getSexo().equalsIgnoreCase("Feminino")){
            somaf = somaf + objTrabalhador2.getSalario();
            nf += 1;
        }
        
        if(objTrabalhador3.getSexo().equalsIgnoreCase("Feminino")){
            somaf = somaf + objTrabalhador3.getSalario();
            nf += 1;
        }
        
        if(objTrabalhador4.getSexo().equalsIgnoreCase("Feminino")){
            somaf = somaf + objTrabalhador4.getSalario();
            nf += 1;
        }
        
        float mediaF = somaf / nf;
    }
    
}
